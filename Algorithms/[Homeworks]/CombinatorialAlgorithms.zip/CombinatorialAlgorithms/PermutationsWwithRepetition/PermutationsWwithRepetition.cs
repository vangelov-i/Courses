﻿namespace PermutationsWwithRepetition
{
    using System;
    using System.Linq;

    public static class PermutationsWithRepetition
    {
        public static void Main()
        {
            //int[] elements = { 1, 0, 0, 0, 0, 0, 0 };

            int[] elements = Console.ReadLine().Split(
                new []{' ',',','=','s','{','}'}, 
                StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse).ToArray();

            Permutate(elements, elements.Length - 1, 0);
        }

        private static void Permutate(int[] arr, int end, int start)
        {
            Console.WriteLine("{{ {0} }}", string.Join(", ", arr));

            for (int left = end - 1; left >= start; left--)
            {
                for (int right = left + 1; right <= end; right++)
                {
                    if (arr[left].CompareTo(arr[right]) != 0)
                    {
                        int old = arr[left];
                        arr[left] = arr[right];
                        arr[right] = old;

                        Permutate(arr, end, left + 1);
                    }
                }

                int firstElement = arr[left];

                for (int i = left; i <= end - 1; i++)
                {
                    arr[i] = arr[i + 1];
                }

                arr[end] = firstElement;
            }
        }
    }
}