﻿namespace GenerateSubsetsOfStringArray
{
    using System;
    using System.Linq;

    class GenerateSubsetsOfStringArray
    {
        private static string[] elements;

        static void Main(string[] args)
        {
            elements = Console.ReadLine().Substring(4).Split(
                new[] { ' ', ',', '=', '{', '}' },
                StringSplitOptions.RemoveEmptyEntries);

            int n = elements.Length;
            int k = int.Parse(Console.ReadLine().Substring(4));

            int[] array = Enumerable.Range(0, k + 1).ToArray();

            GenCombosWithoutRepetition(array, n);
        }

        static void GenCombosWithoutRepetition(int[] array, int n, int index = 0, int start = 0)
        {
            if (index >= array.Length)
            {
                //Console.WriteLine(string.Join(" ", array));
                Console.Write("( ");
                for (int i = 0; i < array.Length - 1; i++)
                {
                    Console.Write(elements[array[i]] + " ");
                }

                Console.WriteLine(")");

                return;
            }

            for (int i = start; i <= n; i++)
            {
                array[index] = i;
                GenCombosWithoutRepetition(array, n, index + 1, i + 1);
            }
        }
    }
}
