﻿namespace Permutations
{
    using System;
    using System.Linq;

    class Permutations
    {
        private static int[] permutation;
        private static int permutationsCount;

        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            int[] elements = Enumerable.Range(1, n).ToArray();
            permutation = new int[n];

            GeneratePermutations(elements, 0);
            Console.WriteLine("Total permutations: " + permutationsCount);
        }

        private static void GeneratePermutations(
            int[] elements, 
            int index)
        {
            if (index >= permutation.Length)
            {
                Console.WriteLine(string.Join(", ", elements));
                permutationsCount++;
                return;
            }

            for (int i = index; i < elements.Length; i++)
            {
                permutation[index] = elements[i];

                int old = elements[index];
                elements[index] = elements[i];
                elements[i] = old; 

                GeneratePermutations(elements, index + 1);

                old = elements[index];
                elements[index] = elements[i];
                elements[i] = old;
            }
        }
    }
}