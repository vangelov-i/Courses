﻿namespace GenerateCombinationsIteratively
{
    using System;
    using System.Linq;

    class GenerateCombinationsIteratively
    {
        private static int[] combination;
        
        static void Main(string[] args)
        {
            int n = 5;
            int k = 3;

            int[] numbers = Enumerable.Range(1, n).ToArray();
            combination = Enumerable.Range(1, k).ToArray();

            int index = k - 1;
            int start = 1;

            // Almost there! :D
            while (true)
            {
                Console.WriteLine(string.Join(" ", combination));
                index = k - 1;
                while (true)
                {
                    combination[index]++;
                    if (combination[index] > n)
                    {
                        index--;
                        combination[index]++;
                        if (combination[index] > n - index)
                        {
                             while (index <= k - 1)
                            {
                                combination[index] = combination[index - 1] + 1;
                                index++;
                            }
                        }

                    }
                    else
                    {
                        break;
                    }

                }
            }
        }
    }
}