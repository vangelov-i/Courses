﻿namespace QueensPuzzleLab
{
    using System;

    class EightQueens
    {
        const int Size = 8;

        static bool[,] chessboard = new bool[Size, Size];
        static bool[] attackedColums = new bool[Size];
        static bool[] attackedLeftDiagonals = new bool[Size * 2 - 1];
        static bool[] attackedRightDiagonals = new bool[Size * 2 - 1];

        static int solutionsFound;

        static void Main(string[] args)
        {
            PutQueens(0);
            Console.WriteLine(solutionsFound);
        }

        static void PutQueens(int row)
        {
            if (row == Size)
            {
                PrintSolution();
            }
            else
            {
                for (int col = 0; col < Size; col++)
                {
                    if (CanPlaceQueen(row, col))
                    {
                        MarkAllAttackedPositions(row, col);
                        PutQueens(row + 1);
                        UnmarkAllAttackedPositions(row, col);
                    }
                }
            }
        }

        private static bool CanPlaceQueen(int row, int col)
        {
            bool result =
                !attackedColums[col] &&
                !attackedRightDiagonals[row + col] &&
                !attackedLeftDiagonals[col - row + Size - 1];

            return result;
        }

        private static void MarkAllAttackedPositions(int row, int col)
        {
            attackedColums[col] = true;
            attackedRightDiagonals[row + col] = true;
            attackedLeftDiagonals[col - row + Size - 1] = true;
            chessboard[row, col] = true;
        }

        private static void UnmarkAllAttackedPositions(int row, int col)
        {
            attackedColums[col] = false;
            attackedRightDiagonals[row + col] = false;
            attackedLeftDiagonals[col - row + Size - 1] = false;
            chessboard[row, col] = false;
        }


        private static void PrintSolution()
        {
            for (int row = 0; row < Size; row++)
            {
                for (int col = 0; col < Size; col++)
                {
                    Console.Write(chessboard[row, col] ? '*' : '-');
                }

                Console.WriteLine();
            }

            Console.WriteLine();

            solutionsFound++;
        }
    }
}
