﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Wintellect.PowerCollections;

public class Program
{
    private static Scoreboard scoreData;

    static void Main()
    {
        scoreData = new Scoreboard();

        string currentLine = Console.ReadLine();
        while (currentLine != "End")
        {
            if (currentLine == string.Empty)
            {
                currentLine = Console.ReadLine();
                continue;
            }

            string[] commandParams = currentLine.Split();
            string comandName = commandParams[0];
            switch (comandName)
            {
                case "RegisterUser":
                    ExecuteRegisterUserCommand(commandParams);
                    break;
                case "RegisterGame":
                    ExecuteRegisterGameCommand(commandParams);
                    break;
                case "AddScore":
                    ExecuteAddScoreCommand(commandParams);
                    break;
                case "ShowScoreboard":
                    ExecuteShowScoreboardCommand(commandParams);
                    break;
                case "ListGamesByPrefix":
                    ExecuteGamesByPrefixCommand(commandParams);
                    break;
                case "DeleteGame":
                    ExecuteDeleteGameCommand(commandParams);
                    break;
            }

            currentLine = Console.ReadLine();
        }
    }

    private static void ExecuteRegisterUserCommand(string[] commandParams)
    {
        string username = commandParams[1];
        string password = commandParams[2];

        bool userRegistered = scoreData.RegisterUser(username, password);
        Console.WriteLine(userRegistered ? "User registered" : "Duplicated user");
    }

    private static void ExecuteRegisterGameCommand(string[] commandParams)
    {
        string name = commandParams[1];
        string password = commandParams[2];

        bool gameRegistered = scoreData.RegisterGame(name, password);
        Console.WriteLine(gameRegistered ? "Game registered" : "Duplicated game");
    }

    private static void ExecuteAddScoreCommand(string[] commandParams)
    {
        string username = commandParams[1];
        string userPassword = commandParams[2];
        string gameName = commandParams[3];
        string gamePassword = commandParams[4];
        int score = int.Parse(commandParams[5]);

        bool scoreAdded = scoreData.AddScore(
            username,
            userPassword,
            gameName,
            gamePassword,
            score);

        Console.WriteLine(scoreAdded ? "Score added" : "Cannot add score");
    }

    private static void ExecuteShowScoreboardCommand(string[] commandParams)
    {
        string gameName = commandParams[1];

        var result = scoreData.GetScoreBoard(gameName);
        Console.Write(result);
    }

    private static void ExecuteGamesByPrefixCommand(string[] commandParams)
    {
        string gameNamePrefix = commandParams[1];

        string result = scoreData.GetFirst10GamesByPrefix(gameNamePrefix);

        Console.WriteLine(result);
    }

    private static void ExecuteDeleteGameCommand(string[] commandParams)
    {
        string gameName = commandParams[1];
        string password = commandParams[2];

        bool gameDeleted = scoreData.DeleteGame(gameName, password);
        Console.WriteLine(gameDeleted ? "Game deleted" : "Cannot delete game");
    }
}

class Scoreboard
{
    private AhoCorasickSearch searchEngine;

    private OrderedDictionary<string, Game> games;
    private Dictionary<string, string> players;

    public Scoreboard()
    {
        this.searchEngine = new AhoCorasickSearch();
        this.games = new OrderedDictionary<string, Game>();
        this.players = new Dictionary<string, string>();
    }

    public bool RegisterUser(string username, string password)
    {
        if (this.players.ContainsKey(username))
        {
            return false;
        }

        this.players.Add(username, password);

        return true;
    }

    public bool RegisterGame(string name, string password)
    {
        if (this.games.ContainsKey(name))
        {
            return false;
        }

        var gameToAdd = new Game(name, password);
        this.games.Add(name, gameToAdd);

        return true;
    }

    public bool AddScore(
        string username,
        string userPassword,
        string gameName,
        string gamePassword,
        int score)
    {
        bool userIsValid = this.ValidateUser(username, userPassword);
        if (!userIsValid)
        {
            return false;
        }

        bool gameIsValid = this.ValidateGame(gameName, gamePassword);
        if (!gameIsValid)
        {
            return false;
        }

        this.games[gameName].AddScore(score, username);

        return true;
    }


    public string GetScoreBoard(string gameName)
    {
        string result = string.Empty;

        if (!this.games.ContainsKey(gameName))
        {
            result = string.Format("Game not found{0}", Environment.NewLine);
            return result;
        }

        result = this.games[gameName].GetTop10Highscore();

        return result;
    }

    public string GetFirst10GamesByPrefix(string namePrefix)
    {
        var result = new OrderedSet<string>();
        foreach (var game in this.games.Keys)
        {
            if (game.StartsWith(namePrefix))
            {
                result.Add(game);
                if (result.Count == 10)
                {
                    break;
                }
            }
        }

        if (result.Count == 0)
        {
            return "No matches";
        }

        return string.Join(", ", result.Take(10));
    }

    //public string GetFirst10GamesByPrefix(string namePrefix)
    //{
    //    var result = new OrderedSet<string>();

    //    string allGames = string.Join(" ", this.games.Keys);
    //    var filteredGames = this.searchEngine.SearchAll(allGames, namePrefix);

    //    foreach (var searchResult in filteredGames)
    //    {
    //        var matchCandidate = searchResult.Match;
    //        if (matchCandidate.StartsWith(namePrefix))
    //        {
    //            // TODO: it might be unnecessary to add all the matches
    //            // even when their count exceeds 10. The OrderedDictionary
    //            // should have done the work so ther should not be bugs
    //            result.Add(matchCandidate);
    //        }
    //    }

    //    if (result.Count == 0)
    //    {
    //        return "No matches";
    //    }

    //    return string.Join(", ", result.Take(10));
    //}

    public bool DeleteGame(string name, string password)
    {
        bool gameIsValid = this.ValidateGame(name, password);
        if (!gameIsValid)
        {
            return false;
        }

        this.games.Remove(name);

        return true;
    }

    private bool ValidateUser(string username, string password)
    {
        bool result = this.players.ContainsKey(username) &&
            this.players[username] == password;

        return result;
    }

    private bool ValidateGame(string name, string password)
    {
        bool result = this.games.ContainsKey(name) && this.games[name].Password == password;

        return result;
    }
}

class Score : IComparable<Score>
{
    public Score(int value)
    {
        this.Value = value;
    }

    public int Value { get; set; }

    public int CompareTo(Score other)
    {
        return other.Value.CompareTo(this.Value);
    }

    public override bool Equals(object obj)
    {
        Score other = obj as Score;

        return this.Value == other.Value;
    }

    public override int GetHashCode()
    {
        return base.GetHashCode();
    }
}

class Player
{
    public Player(string username, string password)
    {
        this.Username = username;
        this.Password = password;
    }

    public string Username { get; set; }

    public string Password { get; set; }

    public override bool Equals(object obj)
    {
        Player other = obj as Player;
        if (other == null)
        {
            return false;
        }

        return this.Username == other.Username;
    }

    public override int GetHashCode()
    {
        return base.GetHashCode();
    }
}

class Game : IComparable<Game>
{
    private OrderedDictionary<Score, OrderedBag<string>> highscore;

    public Game(string name, string password)
    {
        this.Name = name;
        this.Password = password;
        this.highscore = new OrderedDictionary<Score, OrderedBag<string>>();
    }

    public string Name { get; set; }

    public string Password { get; set; }

    public void AddScore(int score, string username)
    {
        var scoreToAdd = new Score(score);
        if (!this.highscore.ContainsKey(scoreToAdd))
        {
            this.highscore[scoreToAdd] = new OrderedBag<string>();
        }

        this.highscore[scoreToAdd].Add(username);
    }

    public string GetTop10Highscore()
    {
        var result = new StringBuilder();

        if (this.highscore.Count == 0)
        {
            result.AppendLine("No score");
            return result.ToString();
        }

        int position = 1;
        foreach (var scorePlayersPair in this.highscore)
        {
            int currentScore = scorePlayersPair.Key.Value;

            foreach (var player in scorePlayersPair.Value)
            {
                result.AppendFormat(
                    "#{0} {1} {2}{3}",
                    position,
                    player,
                    currentScore,
                    Environment.NewLine);

                position++;
                if (position >= 11)
                {
                    return result.ToString();
                }
            }
        }

        return result.ToString();
    }

    public int CompareTo(Game other)
    {
        return this.Name.CompareTo(other.Name);
    }

    public override bool Equals(object obj)
    {
        Game other = obj as Game;
        if (other == null)
        {
            return false;
        }

        return this.Name == other.Name;
    }
}

#region Search Algorithm
/// <summary>
/// 
/// </summary>
/// <remarks>
/// Aho-Corasick exact set matching algorithm
/// Search time: O(n + m + z), where z is number of pattern occurrences
///
/// This implementation is loosely based on http://www.codeproject.com/useritems/ahocorasick.asp
/// 
/// String Matching: An Aid to Bibliographic Search - Alfred V. Aho and Margaret J. Corasick (Bell Laboratories) (http://hidden.dankirsh.com/CS549/paper.pdf)
/// 
/// Set Matching and Aho-Corasick Algorithm - Pekka Kilpeläinen (University of Kuopio) (www.cs.uku.fi/~kilpelai/BSA05/lectures/slides04.pdf)
/// http://www-sr.informatik.uni-tuebingen.de/~buehler/AC/AC.html
/// </remarks>
public class AhoCorasickSearch
{
    public virtual SearchResult[] SearchAll(string text, params string[] keywords)
    {
        return SearchAll(text, 0, int.MaxValue, keywords);
    }

    public virtual SearchResult[] SearchAll(string text, int start, params string[] keywords)
    {
        return SearchAll(text, start, int.MaxValue, keywords);
    }

    public virtual SearchResult SearchFirst(string text, params string[] keywords)
    {
        return SearchFirst(text, 0, keywords);
    }

    public SearchResult[] SearchAll(string text, int start, int count, params string[] keywords)
    {
        CheckArguments(text, start, count);
        CheckKeywords(keywords);

        List<SearchResult> results = null;
        if (count == int.MaxValue)
            results = new List<SearchResult>();
        else
            results = new List<SearchResult>(count);

        foreach (SearchResult result in SearchIterator(text, start, keywords))
        {
            results.Add(result);
            if (results.Count == count)
                break;
        }

        return results.ToArray();
    }

    public SearchResult SearchFirst(string text, int start, params string[] keywords)
    {
        CheckArguments(text, start, int.MaxValue);
        CheckKeywords(keywords);

        IEnumerator<SearchResult> iter = SearchIterator(text, start, keywords).GetEnumerator();
        if (iter.MoveNext())
            return iter.Current;
        return SearchResult.Empty;
    }

    protected static IEnumerable<SearchResult> SearchIterator(string text, int start, params string[] keywords)
    {
        if (start > 0)
            text = text.Substring(start);

        Node root = BuildTree(keywords);
        Node ptr = root;
        int index = 0;

        while (index < text.Length)
        {
            Node trans = null;

            while (trans == null)
            {
                trans = ptr.GetTransition(text[index]);

                if (ptr == root)
                    break;

                if (trans == null)
                    ptr = ptr.Failure;
            }

            if (trans != null)
                ptr = trans;

            if (ptr.Outputs != null)
            {
                foreach (string found in ptr.Outputs)
                    yield return new SearchResult(index - found.Length + 1, found);

            }
            index++;
        }
    }
    /// <summary>
    /// 
    /// </summary>
    /// <param name="keywords"></param>
    /// <returns></returns>
    protected static Node BuildTree(string[] keywords)
    {
        Node root = new Node(null, ' ');

        #region build trie tree
        {
            Node cNode = root;
            Node newNode = null;
            foreach (string keyword in keywords)
            {
                cNode = root;
                // add pattern to tree
                foreach (char c in keyword)
                {
                    newNode = null;

                    if ((newNode = cNode.GetTransition(c)) == null)
                    {
                        newNode = new Node(cNode, c);
                        cNode.AddTransition(newNode);
                    }
                    cNode = newNode;
                }
                cNode.AddResult(keyword);
            }
        }
        #endregion

        // Find failure functions

        var nodesQueue = new Queue<Node>();
        // level 1 nodes - fail to root node
        foreach (Node cNode in root.Transition.Values)
        {
            cNode.Failure = root;

            QueueAddRange(nodesQueue, cNode.Transition.Values);
        }

        {
            Node cNode = null, r = null, nNode = null;
            // other nodes - using BFS
            while (nodesQueue.Count != 0)
            {
                cNode = nodesQueue.Dequeue();
                r = cNode.Parent.Failure;

                while (r != null && (nNode = r.GetTransition(cNode.Char)) == null)
                    r = r.Failure;

                if (r == null)
                {
                    cNode.Failure = root;
                }
                else
                {
                    cNode.Failure = nNode;
                    cNode.AddResults(cNode.Failure.Outputs);
                }

                //add child nodes to BFS list 
                QueueAddRange(nodesQueue, cNode.Transition.Values);
            }
        }
        root.Failure = root;
        return root;
    }

    protected class Node
    {
        internal char Char;
        internal Node Parent;
        internal Node Failure;

        internal HashSet<string> Outputs;
        internal Dictionary<char, Node> Transition;

        public Node(Node parent, char c)
        {
            Char = c;
            Parent = parent;

            Transition = new Dictionary<char, Node>();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="results"></param>
        public void AddResult(string result)
        {
            if (string.IsNullOrEmpty(result))
                return;
            if (Outputs == null)
                Outputs = new HashSet<string>();

            Outputs.Add(result);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="results"></param>
        public void AddResults(IEnumerable<string> results)
        {
            if (results == null)
                return;
            if (Outputs == null)
                Outputs = new HashSet<string>();

            foreach (var result in results)
            {
                Outputs.Add(result);
            }
        }

        public void AddTransition(Node node)
        {
            Transition.Add(node.Char, node);
        }

        public Node GetTransition(char c)
        {
            Node node = null;
            if (Transition.TryGetValue(c, out node))
                return node;
            return null;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="queue"></param>
    /// <param name="collection"></param>
    private static void QueueAddRange(Queue<Node> queue, IEnumerable<Node> collection)
    {
        if (queue == null || collection == null)
            return;

        foreach (var item in collection)
        {
            queue.Enqueue(item);
        }
    }

    protected static void CheckKeywords(params string[] keywords)
    {
        if (keywords == null)
            throw new ArgumentNullException("keywords");
        if (keywords.Length == 0)
            throw new ArgumentException("keywords");

        foreach (string keyword in keywords)
        {
            if (string.IsNullOrEmpty(keyword))
                throw new ArgumentException("The keyword set cannot contain null references or empty strings.");
        }
    }

    [System.Diagnostics.DebuggerHidden]
    protected static void CheckArguments(string text, int start, int count)
    {
        if (text == null)
            throw new ArgumentNullException("text");
        if (text.Length == 0)
            throw new ArgumentException("text");

        if (start < 0)
            throw new ArgumentOutOfRangeException("start");
        if (start >= text.Length)
            throw new ArgumentOutOfRangeException("start");

        if (count <= 0)
            throw new ArgumentOutOfRangeException("count");
    }
}

/// <summary>
/// Container class for <see cref="ISetSearchAlgorithm"/> search results.
/// </summary>
public struct SearchResult : IEquatable<SearchResult>
{
    /// <summary>
    /// 
    /// </summary>
    public static readonly SearchResult Empty = new SearchResult(-1, null);

    /// <summary>
    /// Initializes a new instance of the <see cref="SearchResult"/> struct.
    /// </summary>
    /// <param name="index">The index.</param>
    /// <param name="match">The match.</param>
    internal SearchResult(int index, string match)
        : this()
    {
        Index = index;
        Match = match;
    }

    /// <summary>
    /// Gets the index.
    /// </summary>
    /// <value>The index.</value>
    public int Index { get; internal set; }

    /// <summary>
    /// Gets the length of the Matched keyword.
    /// </summary>
    /// <value>The length.</value>
    public int Length { get; internal set; }

    /// <summary>
    /// Gets the matched keyword.
    /// </summary>
    /// <value>The matched keyword.</value>
    public string Match { get; internal set; }

    /// <summary>
    /// Determines whether the specified <see cref="System.Object"/> is equal to this instance.
    /// </summary>
    /// <param name="obj">The <see cref="System.Object"/> to compare with this instance.</param>
    /// <returns>
    /// 	<c>true</c> if the specified <see cref="System.Object"/> is equal to this instance; otherwise, <c>false</c>.
    /// </returns>
    public override bool Equals(object obj)
    {
        if (obj == null)
            return false;

        SearchResult sr = (SearchResult)obj;
        return Index == sr.Index && Match == sr.Match;
    }
    /// <summary>
    /// 
    /// </summary>
    /// <param name="other"></param>
    /// <returns></returns>
    public bool Equals(SearchResult other)
    {
        return Index == other.Index && Match == other.Match;
    }

    /// <summary>
    /// Returns a hash code for this instance.
    /// </summary>
    /// <returns>
    /// A hash code for this instance, suitable for use in hashing algorithms and data structures like a hash table. 
    /// </returns>
    public override int GetHashCode()
    {
        return Index.GetHashCode() ^ Match.GetHashCode();
    }

    /// <summary>
    /// Implements the operator ==.
    /// </summary>
    /// <param name="sr1">A SearchResult.</param>
    /// <param name="sr2">A SearchResult.</param>
    /// <returns>The result of the comparison.</returns>
    public static bool operator ==(SearchResult sr1, SearchResult sr2)
    {
        return sr1.Index == sr2.Index && sr1.Match == sr2.Match;
    }

    /// <summary>
    /// Implements the operator !=.
    /// </summary>
    /// <param name="sr1">A SearchResult.</param>
    /// <param name="sr2">A SearchResult.</param>
    /// <returns>The result of the comparison.</returns>
    public static bool operator !=(SearchResult sr1, SearchResult sr2)
    {
        return sr1.Index != sr2.Index || sr1.Match != sr2.Match;
    }
}
#endregion